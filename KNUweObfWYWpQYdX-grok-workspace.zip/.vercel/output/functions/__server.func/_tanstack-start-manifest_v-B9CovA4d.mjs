//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B9CovA4d.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/reeks",
			"/zoeken"
		],
		preloads: ["/assets/index-B70x7phw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B70x7phw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-63zkQFBI.js",
			"/assets/utils-B3X-2ea5.js",
			"/assets/search-progress-DQRQX9P9.js",
			"/assets/repeat-EI3LmcgG.js"
		]
	},
	"/reeks": {
		filePath: "/workspace/src/routes/reeks.tsx",
		children: void 0,
		preloads: [
			"/assets/reeks-qNFOgctb.js",
			"/assets/quiz-DvZZv9Do.js",
			"/assets/utils-B3X-2ea5.js",
			"/assets/repeat-EI3LmcgG.js"
		]
	},
	"/zoeken": {
		filePath: "/workspace/src/routes/zoeken.tsx",
		children: void 0,
		preloads: [
			"/assets/zoeken-2EsV-g-L.js",
			"/assets/quiz-DvZZv9Do.js",
			"/assets/utils-B3X-2ea5.js",
			"/assets/search-progress-DQRQX9P9.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
