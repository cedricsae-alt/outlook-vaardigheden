import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as cn, r as useProgress, t as SECTIONS } from "./utils-CxklWp97.mjs";
import { L as require_jsx_runtime, _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as BookOpen, S as CalendarClock, _ as ChevronRight, b as Check, c as Repeat, d as MapPin, f as Laptop, g as Circle, h as Clock, i as Trash2, n as Users, p as GraduationCap, r as TriangleAlert, t as X, u as Monitor, v as ChevronLeft, w as AppWindow, x as CalendarDays } from "../_libs/lucide-react.mjs";
import { a as PLATFORM_STEPS, i as PITFALLS, n as CHECKLIST, o as Quiz, r as PATTERNS, s as SCENARIOS, t as Button } from "./quiz-DA9TA4YI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reeks--qnM4xVk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WEEKDAYS = [
	"ma",
	"di",
	"wo",
	"do",
	"vr",
	"za",
	"zo"
];
var EXCEPTION_DATE = 23;
var SERIES_DATES = [
	9,
	16,
	23,
	30
];
var WEDNESDAYS = [
	2,
	9,
	16,
	23,
	30
];
var EXISTING = [
	{
		day: 7,
		start: "08:30",
		title: "Marketing",
		color: "event-2"
	},
	{
		day: 8,
		start: "10:00",
		title: "Boekhouden",
		color: "event-2"
	},
	{
		day: 10,
		start: "13:30",
		title: "Statistiek",
		color: "event-2"
	}
];
function septemberCells() {
	const cells = [];
	cells.push({
		day: 31,
		inMonth: false
	});
	for (let d = 1; d <= 30; d++) cells.push({
		day: d,
		inMonth: true
	});
	while (cells.length % 7 !== 0) cells.push({
		day: null,
		inMonth: false
	});
	return cells;
}
function OutlookSimulator() {
	const setSimulatorComplete = useProgress((s) => s.setSimulatorComplete);
	const setExceptionComplete = useProgress((s) => s.setExceptionComplete);
	const simulatorComplete = useProgress((s) => s.simulatorComplete);
	const exceptionComplete = useProgress((s) => s.exceptionComplete);
	const [mission, setMission] = (0, import_react.useState)(simulatorComplete ? 2 : 1);
	const [composing, setComposing] = (0, import_react.useState)(false);
	const [title, setTitle] = (0, import_react.useState)("");
	const [start, setStart] = (0, import_react.useState)("16:00");
	const [end, setEnd] = (0, import_react.useState)("17:30");
	const [repeat, setRepeat] = (0, import_react.useState)("none");
	const [repeatOpen, setRepeatOpen] = (0, import_react.useState)(false);
	const [endChoice, setEndChoice] = (0, import_react.useState)("never");
	const [saved, setSaved] = (0, import_react.useState)(simulatorComplete);
	const [shake, setShake] = (0, import_react.useState)(false);
	const [hint, setHint] = (0, import_react.useState)("");
	const [openDate, setOpenDate] = (0, import_react.useState)(null);
	const [openMode, setOpenMode] = (0, import_react.useState)(null);
	const [deleted, setDeleted] = (0, import_react.useState)(exceptionComplete ? [EXCEPTION_DATE] : []);
	const [wrongPulse, setWrongPulse] = (0, import_react.useState)(false);
	const cells = (0, import_react.useMemo)(septemberCells, []);
	(0, import_react.useEffect)(() => {
		if (saved) setSimulatorComplete();
	}, [saved, setSimulatorComplete]);
	(0, import_react.useEffect)(() => {
		if (deleted.includes(EXCEPTION_DATE)) setExceptionComplete();
	}, [deleted, setExceptionComplete]);
	function flash(message) {
		setHint(message);
		setShake(true);
		window.setTimeout(() => setShake(false), 220);
	}
	function startCompose() {
		if (saved) return;
		setComposing(true);
		setHint("");
	}
	function trySave() {
		if (title.trim().length < 3) {
			flash("Vul een duidelijke titel in, bv. Projectgroep Marketing.");
			return;
		}
		if (repeat !== "weekly") {
			flash("Kies Wekelijks — de projectgroep valt elke woensdag.");
			setRepeatOpen(true);
			return;
		}
		if (endChoice !== "date") {
			flash("Zet een einddatum. Een semester mag niet oneindig doorlopen.");
			setRepeatOpen(true);
			return;
		}
		setRepeatOpen(false);
		setComposing(false);
		setSaved(true);
		setMission(2);
		setHint("");
	}
	function clickSeriesEvent(day) {
		if (!saved || mission !== 2 || deleted.includes(day)) return;
		setOpenDate(day);
		setOpenMode(null);
		setHint("");
	}
	function chooseMode(mode) {
		if (openDate !== EXCEPTION_DATE && mode === "this") {
			setWrongPulse(true);
			flash(`Niet ${openDate} september — schrap alleen woensdag ${EXCEPTION_DATE} september.`);
			window.setTimeout(() => setWrongPulse(false), 400);
			return;
		}
		if (openDate === EXCEPTION_DATE && mode === "series") {
			setWrongPulse(true);
			flash("Niet de hele reeks. Kies Deze gebeurtenis, anders verdwijnt het hele semester.");
			window.setTimeout(() => setWrongPulse(false), 400);
			return;
		}
		setOpenMode(mode);
	}
	function confirmDelete() {
		if (openDate == null || openMode !== "this") {
			flash("Kies eerst Deze gebeurtenis.");
			return;
		}
		if (openDate !== EXCEPTION_DATE) {
			flash(`Schrap alleen ${EXCEPTION_DATE} september.`);
			return;
		}
		setDeleted((d) => [...d, openDate]);
		setOpenDate(null);
		setOpenMode(null);
	}
	const stepLabel = !saved ? composing ? "Vul de reeks in" : "Start een nieuwe gebeurtenis" : deleted.includes(EXCEPTION_DATE) ? "Klaar" : "Schrap één uitgevallen les";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-elevated)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 border-b border-border bg-surface-2 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-primary uppercase",
					children: "Oefenagenda · september 2026"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-display text-xl font-medium text-fg",
					children: mission === 1 ? "Opdracht 1 — wekelijkse projectgroep" : "Opdracht 2 — één les schrappen"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-xl text-sm leading-relaxed text-muted",
					children: mission === 1 ? "Maak Projectgroep Marketing, wekelijks op woensdag van 16:00 tot 17:30, tot eind december." : `Woensdag ${EXCEPTION_DATE} september valt uit. Verwijder alleen die keer, niet de reeks.`
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 self-start rounded-md bg-event-soft px-3 py-2 text-sm text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, {
					className: "size-4",
					"aria-hidden": true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: stepLabel })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid lg:grid-cols-[minmax(0,1fr)_20rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 p-3 sm:p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1 text-fg",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-10 items-center justify-center text-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-36 text-center text-sm font-medium",
									children: "september 2026"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-10 items-center justify-center text-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							onClick: startCompose,
							disabled: saved,
							className: cn(!composing && !saved && "ring-2 ring-primary/40"),
							children: "Nieuwe gebeurtenis"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-7 gap-px overflow-hidden rounded-md bg-border text-center",
						children: [WEEKDAYS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-surface-2 py-2 text-xs font-medium tracking-wide text-muted uppercase",
							children: d
						}, d)), cells.map((cell, i) => {
							const isSeries = saved && cell.inMonth && cell.day != null && SERIES_DATES.includes(cell.day);
							const isGone = cell.day != null && deleted.includes(cell.day);
							const existing = EXISTING.filter((e) => cell.inMonth && e.day === cell.day);
							const isWed = cell.inMonth && cell.day != null && WEDNESDAYS.includes(cell.day);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("min-h-20 bg-surface p-1.5 text-left sm:min-h-24", !cell.inMonth && "bg-bg-warm/60 text-subtle", isWed && !saved && "bg-event-soft/40"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs tabular-nums text-muted",
									children: cell.day ?? ""
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex flex-col gap-1",
									children: [
										existing.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "truncate rounded-xs bg-event-2-soft px-1.5 py-0.5 text-xs leading-tight text-event-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "hidden sm:inline",
												children: [e.start, " · "]
											}), e.title]
										}, e.title)),
										isSeries && !isGone && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => cell.day != null && clickSeriesEvent(cell.day),
											className: cn("flex items-start gap-1 rounded-xs bg-event-soft px-1.5 py-0.5 text-left text-xs leading-tight text-primary", mission === 2 && cell.day === EXCEPTION_DATE && "ring-2 ring-primary"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "mt-0.5 size-2.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "truncate",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "hidden sm:inline",
													children: "16:00 · "
												}), "Projectgroep"]
											})]
										}),
										isGone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "rounded-xs bg-danger-soft px-1.5 py-0.5 text-xs text-danger line-through",
											children: "Geschrapt"
										})
									]
								})]
							}, i);
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs leading-relaxed text-muted",
						children: "Woensdagen zijn licht gemarkeerd. Bestaande vakken blijven staan — jouw reeks komt erbovenop."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "border-t border-border bg-surface-2 p-4 lg:border-t-0 lg:border-l",
				children: [
					!composing && openDate == null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coach, {
						shake,
						hint,
						saved,
						done: deleted.includes(EXCEPTION_DATE),
						mission
					}),
					composing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventForm, {
						title,
						setTitle,
						start,
						setStart,
						end,
						setEnd,
						repeat,
						setRepeat,
						repeatOpen,
						setRepeatOpen,
						endChoice,
						setEndChoice,
						onClose: () => setComposing(false),
						onSave: trySave,
						shake,
						hint
					}),
					openDate != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditPanel, {
						day: openDate,
						mode: openMode,
						onMode: chooseMode,
						onDelete: confirmDelete,
						onClose: () => {
							setOpenDate(null);
							setOpenMode(null);
						},
						shake: shake || wrongPulse,
						hint
					})
				]
			})]
		})]
	});
}
function Coach({ shake, hint, saved, done, mission }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-3", shake && "shake"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-primary uppercase",
				children: "Coach"
			}),
			done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg text-fg",
					children: "Beide opdrachten klaar."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: "Je hebt een reeks gezet mét einddatum, en één uitzondering geschrapt zonder de rest te wissen. Dat is het hele trucje."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-md bg-success-soft px-3 py-2 text-sm text-success",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Opgeslagen in je voortgang"]
				})
			] }) : !saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-lg text-fg",
				children: "Klik op Nieuwe gebeurtenis."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "space-y-2 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1. Titel: Projectgroep Marketing" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2. Tijd: 16:00–17:30" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "3. Niet herhalen → Wekelijks" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "4. Eindigt op: 16 december 2026" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "5. Opslaan" })
				]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-lg text-fg",
				children: [
					"Klik de reeks op ",
					EXCEPTION_DATE,
					" sep."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "Outlook vraagt wat je wilt openen. Voor een uitgevallen les kies je Deze gebeurtenis — nooit de hele reeks."
			})] }),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-warn-soft px-3 py-2 text-sm text-warn",
				children: hint
			}),
			mission === 2 && saved && !done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-subtle",
				children: [
					"Het blok op ",
					EXCEPTION_DATE,
					" september heeft een ring."
				]
			})
		]
	});
}
function EventForm({ title, setTitle, start, setStart, end, setEnd, repeat, setRepeat, repeatOpen, setRepeatOpen, endChoice, setEndChoice, onClose, onSave, shake, hint }) {
	const repeatLabel = repeat === "weekly" ? "Wekelijks op woensdag" : repeat === "custom" ? "Aangepast" : "Niet herhalen";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-4", shake && "shake"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg text-fg",
					children: "Nieuwe gebeurtenis"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "flex size-10 items-center justify-center rounded-sm text-muted hover:bg-bg-warm",
					"aria-label": "Sluiten",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1.5 block text-xs font-medium text-muted",
					children: "Titel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: "Projectgroep Marketing",
					className: "h-11 w-full rounded-sm bg-surface px-3 text-sm shadow-[var(--shadow-border)] outline-none focus:ring-2 focus:ring-ring"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mb-1.5 flex items-center gap-1 text-xs font-medium text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" }), " Start"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "time",
					value: start,
					onChange: (e) => setStart(e.target.value),
					className: "h-11 w-full rounded-sm bg-surface px-3 text-sm shadow-[var(--shadow-border)] outline-none focus:ring-2 focus:ring-ring"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1.5 block text-xs font-medium text-muted",
					children: "Einde"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "time",
					value: end,
					onChange: (e) => setEnd(e.target.value),
					className: "h-11 w-full rounded-sm bg-surface px-3 text-sm shadow-[var(--shadow-border)] outline-none focus:ring-2 focus:ring-ring"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mb-1.5 flex items-center gap-1 text-xs font-medium text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "size-3" }), " Herhalen"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setRepeatOpen(!repeatOpen),
					className: "flex h-11 w-full items-center justify-between rounded-sm bg-surface px-3 text-left text-sm shadow-[var(--shadow-border)]",
					children: [repeatLabel, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: cn("size-4 text-muted transition-transform duration-150", repeatOpen && "rotate-90") })]
				}),
				repeatOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 space-y-1 rounded-md bg-surface p-1 shadow-[var(--shadow-border)]",
					children: [[
						["none", "Niet herhalen"],
						["weekly", "Wekelijks op woensdag"],
						["custom", "Aangepast…"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setRepeat(id);
							if (id === "none") setEndChoice("never");
						},
						className: cn("flex h-10 w-full items-center rounded-sm px-3 text-left text-sm", repeat === id ? "bg-event-soft text-primary" : "hover:bg-bg-warm"),
						children: label
					}, id)), repeat === "weekly" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 space-y-2 border-t border-border px-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-muted",
								children: "Einde van de reeks"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-10 items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "radio",
									name: "end",
									checked: endChoice === "never",
									onChange: () => setEndChoice("never"),
									className: "size-4 accent-primary"
								}), "Geen einddatum"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-10 items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "radio",
									name: "end",
									checked: endChoice === "date",
									onChange: () => setEndChoice("date"),
									className: "size-4 accent-primary"
								}), "Eindigt op 16 december 2026"]
							})
						]
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), "Lokaal B.2.14"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }), "3 groepsgenoten (oefening slaat lokaal op)"]
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-warn-soft px-3 py-2 text-sm text-warn",
				children: hint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				className: "w-full",
				onClick: onSave,
				children: "Opslaan"
			})
		]
	});
}
function EditPanel({ day, mode, onMode, onDelete, onClose, shake, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-4", shake && "shake"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg text-fg",
					children: "Projectgroep Marketing"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 flex items-center gap-1.5 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-3.5" }),
						"woensdag ",
						day,
						" september · 16:00–17:30"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "flex size-10 items-center justify-center rounded-sm text-muted hover:bg-bg-warm",
					"aria-label": "Sluiten",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "Dit is een terugkerende gebeurtenis. Wat wil je openen?"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onMode("this"),
					className: cn("flex min-h-12 w-full items-center rounded-md px-3 text-left text-sm shadow-[var(--shadow-border)]", mode === "this" ? "bg-event-soft text-primary" : "bg-surface hover:bg-bg-warm"),
					children: "Deze gebeurtenis"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onMode("series"),
					className: cn("flex min-h-12 w-full items-center rounded-md px-3 text-left text-sm shadow-[var(--shadow-border)]", mode === "series" ? "bg-danger-soft text-danger" : "bg-surface hover:bg-bg-warm"),
					children: "Alle gebeurtenissen in de reeks"
				})]
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-warn-soft px-3 py-2 text-sm text-warn",
				children: hint
			}),
			mode === "this" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				className: "w-full text-danger",
				onClick: onDelete,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Deze keer verwijderen"]
			})
		]
	});
}
function GuideApp() {
	const [active, setActive] = (0, import_react.useState)("start");
	const markVisited = useProgress((s) => s.markVisited);
	const visited = useProgress((s) => s.visited);
	const simulatorComplete = useProgress((s) => s.simulatorComplete);
	const exceptionComplete = useProgress((s) => s.exceptionComplete);
	const checks = useProgress((s) => s.checks);
	const quiz = useProgress((s) => s.quiz);
	(0, import_react.useEffect)(() => {
		useProgress.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		markVisited(active);
	}, [active, markVisited]);
	const checkedCount = CHECKLIST.filter((c) => checks[c.id]).length;
	const quizDone = Object.keys(quiz).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh overflow-x-hidden bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#inhoud",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-fg",
				children: "Naar inhoud"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border bg-surface/80 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-3 text-fg no-underline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-9 items-center justify-center rounded-sm bg-primary text-primary-fg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, {
								className: "size-4",
								"aria-hidden": true
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg font-medium leading-none text-fg",
							children: "Reeks"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "Outlook-gids · BM1"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-sm text-muted sm:block",
						children: "10 minuten"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid min-w-0 max-w-6xl lg:grid-cols-[16.5rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Hoofdstukken",
					className: "sticky top-0 z-20 min-w-0 overflow-x-hidden border-b border-border bg-bg/95 lg:h-dvh lg:overflow-y-auto lg:border-r lg:border-b-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-1 overflow-x-auto px-3 py-2 lg:flex-col lg:gap-0.5 lg:px-4 lg:py-6",
						children: SECTIONS.map((s) => {
							const isActive = active === s.id;
							const done = Boolean(visited[s.id]) && (s.id !== "oefenen" || simulatorComplete && exceptionComplete) && (s.id !== "checklist" || checkedCount === CHECKLIST.length) && (s.id !== "quiz" || quizDone === 6);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setActive(s.id),
								className: cn("flex h-11 shrink-0 items-center gap-2 rounded-md px-3 text-left text-sm whitespace-nowrap transition-colors duration-150 lg:h-10 lg:w-full", isActive ? "bg-primary text-primary-fg" : "text-muted hover:bg-bg-warm hover:text-fg"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden lg:flex",
										children: done && !isActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "size-3.5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "lg:hidden",
										children: s.short
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden lg:inline",
										children: s.label
									})
								]
							}, s.id);
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					id: "inhoud",
					className: "min-w-0 overflow-x-hidden px-4 py-8 sm:px-8 sm:py-10",
					children: [
						active === "start" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Start, { onNext: () => setActive("begrippen") }),
						active === "begrippen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Begrippen, { onNext: () => setActive("oefenen") }),
						active === "oefenen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Oefenen, { onNext: () => setActive("stappen") }),
						active === "stappen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stappen, { onNext: () => setActive("patronen") }),
						active === "patronen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Patronen, { onNext: () => setActive("wijzigen") }),
						active === "wijzigen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wijzigen, { onNext: () => setActive("situaties") }),
						active === "situaties" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Situaties, { onNext: () => setActive("valkuilen") }),
						active === "valkuilen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Valkuilen, { onNext: () => setActive("checklist") }),
						active === "checklist" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checklist, { onNext: () => setActive("quiz") }),
						active === "quiz" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toets, {})
					]
				})]
			})
		]
	});
}
function SectionHead({ kicker, title, lead }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "stagger-in mb-8 max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-primary uppercase",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl font-medium tracking-tight text-fg sm:text-4xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base leading-relaxed text-muted",
				children: lead
			})
		]
	});
}
function NextButton({ onNext, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			size: "lg",
			onClick: onNext,
			children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
		})
	});
}
function Start({ onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Handleiding",
			title: "Terugkerende afspraken in Outlook, zonder je semester te slopen.",
			lead: "Voor 1ste bachelor Bedrijfsmanagement. In tien minuten leer je een reeks zetten, het juiste patroon kiezen, en één les schrappen zonder de rest mee te nemen."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				{
					icon: Repeat,
					title: "Eén keer plannen",
					body: "Wekelijkse projectgroep, studieblok of stagecheck — Outlook herhaalt het voor je."
				},
				{
					icon: Users,
					title: "Alleen of met anderen",
					body: "Afspraak = alleen jij. Vergadering = deelnemers krijgen één uitnodiging voor de hele reeks."
				},
				{
					icon: TriangleAlert,
					title: "De gevaarlijke knop",
					body: "‘Hele reeks’ wist of wijzigt alles. ‘Deze gebeurtenis’ raakt één dag."
				}
			].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(card.icon, {
						className: "size-5 text-primary",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-lg font-medium",
						children: card.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: card.body
					})
				]
			}, card.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-lg bg-surface-2 p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm font-medium text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-4 text-primary" }), "Wat je nodig hebt"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Je hogeschoolaccount (Microsoft 365) — meestal outlook.office.com." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "De webagenda werkt op laptop, Chromebook en telefoon. De Windows-app is optioneel." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Geen installatie voor deze handleiding: oefen eerst hier, daarna in het echt." })
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Eerst de begrippen"
		})
	] });
}
function Begrippen({ onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Begrippen",
			title: "Drie woorden die je niet mag door elkaar halen.",
			lead: "Outlook gebruikt dezelfde knoppen voor een eenmalige les, een wekelijkse werkgroep en een uitnodiging aan je team. Het verschil zit in deelnemers en in herhalen."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-lg shadow-[var(--shadow-border)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[32rem] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "bg-surface-2 text-xs tracking-wide text-muted uppercase",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Woord"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Wat het is"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Wanneer"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
					className: "bg-surface",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: "Afspraak"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Staat alleen in jouw agenda. Niemand krijgt mail."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Studieblok, job, herinnering"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: "Vergadering"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Je nodigt mensen uit. Zij accepteren of weigeren."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Projectgroep, stagegesprek"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: "Reeks"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Dezelfde afspraak of vergadering, herhaald volgens een patroon."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Elke woensdag tot de deadline"
								})
							]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-medium",
					children: "Niet herhalen"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: "Standaard. Eén blok, één dag. Gebruik dit voor een examen, een gastcollege of een eenmalige afspraak met de docent."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-medium",
					children: "Wel herhalen"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: "Outlook maakt de volgende keren automatisch. Jij (en je groepsgenoten) zien ze als losse blokken, maar ze horen bij één reeks."
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 max-w-2xl text-sm leading-relaxed text-muted",
			children: [
				"Op je telefoon en in de webagenda heten de knoppen vaak",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-medium text-fg",
					children: "Nieuwe gebeurtenis"
				}),
				" en",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-medium text-fg",
					children: "Niet herhalen"
				}),
				". In de klassieke Windows-app:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-medium text-fg",
					children: "Nieuwe afspraak"
				}),
				" of",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-medium text-fg",
					children: "Herhaling"
				}),
				"."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Oefen het in de nep-agenda"
		})
	] });
}
function Oefenen({ onNext }) {
	const sim = useProgress((s) => s.simulatorComplete);
	const exc = useProgress((s) => s.exceptionComplete);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Oefenagenda",
			title: "Doe het eerst hier. Dan in Outlook.",
			lead: "Twee opdrachten, dezelfde klikken als in de echte agenda. De coach laat je niet verder als het patroon of de einddatum ontbreekt."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutlookSimulator, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex flex-wrap gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, {
				ok: sim,
				label: "Reeks gezet"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, {
				ok: exc,
				label: "Uitzondering geschrapt"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Stappen in de echte Outlook"
		})
	] });
}
function StatusChip({ ok, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-md px-3 py-2", ok ? "bg-success-soft text-success" : "bg-bg-warm text-muted"),
		children: [ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "size-3.5" }), label]
	});
}
function Stappen({ onNext }) {
	const [platform, setPlatform] = (0, import_react.useState)("web");
	const data = PLATFORM_STEPS[platform];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "In het echt",
			title: "Zelfde reeks, drie Outlooks.",
			lead: "De meeste studenten werken in de browser. De nieuwe app lijkt daar sterk op. De klassieke Windows-app heeft een extra venster ‘Afspraakherhaling’."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6 flex flex-wrap gap-2",
			children: [
				[
					"web",
					"Web",
					Laptop
				],
				[
					"new",
					"Nieuwe app",
					Monitor
				],
				[
					"classic",
					"Klassiek",
					AppWindow
				]
			].map(([id, label, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setPlatform(id),
				className: cn("inline-flex h-11 items-center gap-2 rounded-md px-4 text-sm transition-colors duration-150", platform === id ? "bg-primary text-primary-fg" : "bg-surface text-muted shadow-[var(--shadow-border)] hover:text-fg"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
			}, id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm font-medium text-fg",
			children: data.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "space-y-3",
			children: data.steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-4 rounded-lg bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-8 shrink-0 items-center justify-center rounded-sm bg-event-soft font-display text-sm text-primary tabular-nums",
					children: i + 1
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-medium text-fg",
					children: step.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: step.body
				})] })]
			}, step.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-sm leading-relaxed text-muted",
			children: [
				"Sneltoets klassiek:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
					className: "rounded-xs bg-bg-warm px-1.5 py-0.5 text-fg",
					children: "Ctrl+Shift+Q"
				}),
				" ",
				"nieuwe vergadering,",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
					className: "rounded-xs bg-bg-warm px-1.5 py-0.5 text-fg",
					children: "Ctrl+G"
				}),
				" ",
				"herhaling."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Welk patroon kies ik?"
		})
	] });
}
function Patronen({ onNext }) {
	const [active, setActive] = (0, import_react.useState)(PATTERNS[2].id);
	const current = PATTERNS.find((p) => p.id === active) ?? PATTERNS[2];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Patronen",
			title: "Kies het patroon op de week, niet op het gevoel.",
			lead: "‘Wekelijks’ is bijna altijd het juiste antwoord in BM. ‘Elke 2 weken’ zit verstopt onder Aangepast. ‘Dag 1 van de maand’ is bijna nooit wat je wilt."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[14rem_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto lg:flex-col",
				children: PATTERNS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setActive(p.id),
					className: cn("h-11 shrink-0 rounded-md px-4 text-left text-sm lg:w-full", active === p.id ? "bg-primary text-primary-fg" : "bg-surface text-muted shadow-[var(--shadow-border)] hover:text-fg"),
					children: p.name
				}, p.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-medium",
						children: current.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: current.use
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 rounded-md bg-event-soft px-4 py-3 text-sm leading-relaxed text-primary",
						children: current.how
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatternPreview, { id: current.id })
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-lg bg-surface-2 p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarClock, { className: "size-4 text-primary" }), "Altijd een einde"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-medium text-fg",
						children: "Eindigt op"
					}), " — laatste lesweek, presentatiedag, einde stage."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-medium text-fg",
						children: "Eindigt na N keer"
					}), " — handig als je 12 werksessies telt."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-medium text-fg",
						children: "Geen einddatum"
					}), " — alleen voor iets dat echt niet stopt (en bijna nooit voor school)."] })
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Wijzigen zonder schade"
		})
	] });
}
function PatternPreview({ id }) {
	const days = Array.from({ length: 14 }, (_, i) => i + 1);
	const on = (d) => {
		if (id === "daily") return true;
		if (id === "weekdays") return d % 7 !== 6 && d % 7 !== 0;
		if (id === "weekly") return d % 7 === 3;
		if (id === "biweekly") return d === 3;
		if (id === "monthly") return d === 1;
		return false;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2 text-xs font-medium tracking-wide text-muted uppercase",
			children: "Twee weken, visueel"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-7 gap-1",
			children: [[
				"ma",
				"di",
				"wo",
				"do",
				"vr",
				"za",
				"zo"
			].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center text-xs tracking-wide text-subtle uppercase",
				children: d
			}, d)), days.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("flex h-9 items-center justify-center rounded-xs text-xs tabular-nums", on(d) ? "bg-primary text-primary-fg" : "bg-bg-warm text-subtle"),
				children: d
			}, d))]
		})]
	});
}
function Wijzigen({ onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Wijzigen",
			title: "Drie keuzes. Eén daarvan is gevaarlijk.",
			lead: "Als je een herhaalde gebeurtenis opent, vraagt Outlook wat je bedoelt. Lees die vraag. Altijd."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: [
				{
					title: "Deze gebeurtenis",
					body: "Alleen die dag. Gebruik bij ziekte, een uitgevallen les, een lokaalwissel voor één keer, of een extra kwartier.",
					tone: "ok"
				},
				{
					title: "Deze en volgende gebeurtenissen",
					body: "Vanaf die datum een nieuwe regel, de vorige keren blijven. Zit in de webagenda en nieuwe Outlook. Klassiek heeft dit vaak niet.",
					tone: "ok"
				},
				{
					title: "Alle gebeurtenissen in de reeks",
					body: "Past of wist élke keer, ook die in het verleden. Alleen als het uur, de dag of de deelnemers voor altijd veranderen.",
					tone: "warn"
				}
			].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: cn("rounded-lg p-5 shadow-[var(--shadow-border)]", item.tone === "warn" ? "bg-warn-soft" : "bg-surface"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: cn("font-display text-lg font-medium", item.tone === "warn" ? "text-warn" : "text-fg"),
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("mt-2 text-sm leading-relaxed", item.tone === "warn" ? "text-warn" : "text-muted"),
					children: item.body
				})]
			}, item.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-3 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-medium",
					children: "Vergadering updaten"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: [
						"Na een wijziging aan de reeks:",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-medium text-fg",
							children: "Update verzenden"
						}),
						". Nooit een tweede nieuwe gebeurtenis maken — dan zitten er dubbels in ieders agenda."
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-medium",
					children: "Iets vanaf nu anders"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: "Web: Deze en volgende. Klassiek: zet de oude reeks op eindigen de dag vóór de wijziging, en maak een nieuwe reeks vanaf de nieuwe datum."
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Vier BM-situaties"
		})
	] });
}
function Situaties({ onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Situaties",
			title: "Kopieer het patroon, niet de titel.",
			lead: "Dit zijn de vier reeksen die je in het eerste jaar het vaakst nodig hebt. Pas titel en uren aan, houd het patroon."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: SCENARIOS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: s.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: s.when
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs font-medium tracking-wide text-subtle uppercase",
							children: "Patroon"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-sm",
							children: s.pattern
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs font-medium tracking-wide text-subtle uppercase",
							children: "Einde"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-sm",
							children: s.end
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 rounded-md bg-surface-2 px-3 py-2 text-sm leading-relaxed text-muted",
						children: s.tip
					})
				]
			}, s.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Vijf valkuilen"
		})
	] });
}
function Valkuilen({ onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Valkuilen",
			title: "De fouten die iedereen een keer maakt.",
			lead: "Meestal niet uit onkunde, maar omdat Outlook twee dingen met bijna dezelfde naam naast elkaar zet."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: PITFALLS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "flex items-center gap-2 font-display text-lg font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-warn" }), p.title]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: p.problem
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 rounded-md bg-success-soft px-3 py-2 text-sm leading-relaxed text-success",
						children: p.fix
					})
				]
			}, p.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Checklist voor je het verstuurt"
		})
	] });
}
function Checklist({ onNext }) {
	const checks = useProgress((s) => s.checks);
	const toggle = useProgress((s) => s.toggleCheck);
	const n = CHECKLIST.filter((c) => checks[c.id]).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Checklist",
			title: "Acht punten, daarna verzenden.",
			lead: "Vink af terwijl je de echte gebeurtenis maakt. Je voortgang blijft bewaard op dit toestel."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-4 text-sm tabular-nums text-muted",
			children: [
				n,
				" / ",
				CHECKLIST.length,
				" afgevinkt"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: CHECKLIST.map((c) => {
				const on = Boolean(checks[c.id]);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => toggle(c.id),
					className: cn("flex min-h-14 w-full items-start gap-3 rounded-lg px-4 py-3 text-left text-sm leading-snug shadow-[var(--shadow-border)]", on ? "bg-success-soft text-success" : "bg-surface text-fg"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-xs ring-1", on ? "bg-success text-primary-fg ring-success" : "ring-border"),
						children: on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" })
					}), c.text]
				}) }, c.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Toets van zes vragen"
		})
	] });
}
function Toets() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Toets",
			title: "Zes vragen. Directe uitleg.",
			lead: "Geen cijfer voor school — wel een check of je de gevaarlijke knop herkent voor je hem in het echt indrukt."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quiz, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-10 flex items-center gap-2 text-sm text-subtle",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" }), "Labels kunnen licht verschillen per taal en Outlook-versie. Twijfel je: kijk naar Herhalen / Repeat, niet naar het icoon alleen."]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-xs leading-relaxed text-subtle",
			children: "Stappen gebaseerd op Microsoft-ondersteuning voor nieuwe Outlook, Outlook op het web en klassieke Outlook. Jouw hogeschool kan extra beleidsregels hebben voor Teams-vergaderingen."
		})
	] });
}
function ReeksPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuideApp, {});
}
//#endregion
export { ReeksPage as component };
