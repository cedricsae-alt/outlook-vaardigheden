import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as cn } from "./utils-CxklWp97.mjs";
import { L as require_jsx_runtime, _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as BookOpen, _ as ChevronRight, a as Star, b as Check, f as Laptop, g as Circle, l as Paperclip, m as Funnel, o as Search, r as TriangleAlert, t as X, u as Monitor, w as AppWindow, y as ChevronDown } from "../_libs/lucide-react.mjs";
import { o as Quiz, t as Button } from "./quiz-DA9TA4YI.mjs";
import { n as useSearchProgress, t as SEARCH_SECTIONS } from "./search-progress-CgbG9vcV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/zoeken-DOgZuJnM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TARGET_ID = "m-claes-opdracht";
var MAILS = [
	{
		id: TARGET_ID,
		from: "Annemie Claes",
		fromKey: "claes",
		toMe: true,
		subject: "Opdracht 1 Marketing — briefing",
		preview: "In bijlage de pdf met de case en de deadline van 30 september.",
		when: "wo 3 sep",
		bucket: "last-week",
		unread: true,
		flagged: true,
		hasAttachment: true,
		attachmentName: "briefing-opdracht1.pdf",
		folder: "lesmateriaal",
		invite: false
	},
	{
		id: "m-claes-rooster",
		from: "Annemie Claes",
		fromKey: "claes",
		toMe: true,
		subject: "Lesrooster Marketing gewijzigd",
		preview: "Woensdag start om 10:00 in lokaal B.2.14, niet B.1.08.",
		when: "vandaag",
		bucket: "today",
		unread: true,
		flagged: false,
		hasAttachment: false,
		folder: "inbox",
		invite: false
	},
	{
		id: "m-kring",
		from: "Studentenkring BM",
		fromKey: "kring",
		toMe: false,
		subject: "Cantus vrijdag — inschrijven",
		preview: "Schrijf je in vóór donderdag. Geen lesmateriaal, wel feest.",
		when: "gisteren",
		bucket: "last-week",
		unread: true,
		flagged: false,
		hasAttachment: false,
		folder: "inbox",
		invite: false
	},
	{
		id: "m-lien",
		from: "Lien Peeters",
		fromKey: "lien",
		toMe: true,
		subject: "Projectgroep — Excel-planning",
		preview: "Ik zette de taken in het bestand. Check kolom C.",
		when: "vr 4 sep",
		bucket: "last-week",
		unread: false,
		flagged: false,
		hasAttachment: true,
		attachmentName: "planning.xlsx",
		folder: "project",
		invite: false
	},
	{
		id: "m-acker",
		from: "Karel Van Acker",
		fromKey: "acker",
		toMe: true,
		subject: "Oefeningen boekhouden H3",
		preview: "Maak oefening 12 tot 15. Geen bijlage deze keer, staat op Toledo.",
		when: "di 1 sep",
		bucket: "last-week",
		unread: false,
		flagged: false,
		hasAttachment: false,
		folder: "lesmateriaal",
		invite: false
	},
	{
		id: "m-stage",
		from: "Stagebureau",
		fromKey: "stage",
		toMe: true,
		subject: "Infoavond stages 2de jaar",
		preview: "Dinsdag 12:30 in de aula. Bevestig je aanwezigheid.",
		when: "vandaag",
		bucket: "today",
		unread: true,
		flagged: false,
		hasAttachment: false,
		folder: "inbox",
		invite: true
	},
	{
		id: "m-invite",
		from: "Lien Peeters",
		fromKey: "lien",
		toMe: true,
		subject: "Projectgroep Marketing",
		preview: "Uitnodiging voor een wekelijkse vergadering, woensdag 16:00.",
		when: "ma 31 aug",
		bucket: "last-week",
		unread: false,
		flagged: false,
		hasAttachment: false,
		folder: "inbox",
		invite: true
	},
	{
		id: "m-claes-old",
		from: "Annemie Claes",
		fromKey: "claes",
		toMe: true,
		subject: "Welkom in Marketing",
		preview: "Syllabus staat op Toledo. Geen bijlage in deze mail.",
		when: "24 aug",
		bucket: "older",
		unread: false,
		flagged: false,
		hasAttachment: false,
		folder: "lesmateriaal",
		invite: false
	},
	{
		id: "m-deadline",
		from: "Coördinatie BM",
		fromKey: "coord",
		toMe: true,
		subject: "Deadline verslag professionele vaardigheden",
		preview: "Inleveren via Toledo, geen mail naar de docent.",
		when: "vandaag",
		bucket: "today",
		unread: true,
		flagged: true,
		hasAttachment: false,
		folder: "inbox",
		invite: false
	},
	{
		id: "m-pdf-other",
		from: "Karel Van Acker",
		fromKey: "acker",
		toMe: true,
		subject: "Slides H3",
		preview: "Pdf van de slides, ter info.",
		when: "vandaag",
		bucket: "today",
		unread: false,
		flagged: false,
		hasAttachment: true,
		attachmentName: "H3-slides.pdf",
		folder: "inbox",
		invite: false
	},
	{
		id: "m-cc",
		from: "Lien Peeters",
		fromKey: "lien",
		toMe: false,
		subject: "Vraag aan de docent over de case",
		preview: "Je staat in CC. De vraag ging naar Claes, jij mag meelezen.",
		when: "do 2 sep",
		bucket: "last-week",
		unread: true,
		flagged: false,
		hasAttachment: false,
		folder: "inbox",
		invite: false
	}
];
var FOLDERS = [
	{
		id: "inbox",
		label: "Postvak IN"
	},
	{
		id: "lesmateriaal",
		label: "Lesmateriaal"
	},
	{
		id: "project",
		label: "Projectgroep"
	}
];
function parseQuery(raw) {
	let rest = raw.trim();
	const parsed = {
		words: [],
		phrases: []
	};
	const take = (re, assign) => {
		rest = rest.replace(re, (_, v) => {
			assign(v);
			return " ";
		});
	};
	take(/\breceived:"([^"]+)"/gi, (v) => {
		const t = v.toLowerCase();
		if (t.includes("today")) parsed.received = "today";
		else if (t.includes("last")) parsed.received = "last-week";
		else if (t.includes("week")) parsed.received = "this-week";
	});
	take(/\breceived:(\S+)/gi, (v) => {
		const t = v.toLowerCase().replace(/_/g, " ");
		if (t.includes("today")) parsed.received = "today";
		else if (t.includes("last")) parsed.received = "last-week";
		else if (t.includes("week")) parsed.received = "this-week";
	});
	take(/\bfrom:(\S+)/gi, (v) => {
		parsed.from = v.toLowerCase();
	});
	take(/\bsubject:(\S+)/gi, (v) => {
		parsed.subject = v.toLowerCase();
	});
	take(/\bhasattachment:(yes|true|no|false)/gi, (v) => {
		parsed.hasAttachment = /yes|true/i.test(v);
	});
	take(/\bread:(no|false|yes|true)/gi, (v) => {
		parsed.unread = /no|false/i.test(v);
	});
	rest = rest.replace(/"([^"]+)"/g, (_, p) => {
		parsed.phrases.push(p.toLowerCase());
		return " ";
	});
	parsed.words = rest.split(/\s+/).map((w) => w.toLowerCase()).filter((w) => w && w !== "and");
	return parsed;
}
function bucketOk(mail, received) {
	if (!received) return true;
	if (received === "today") return mail.bucket === "today";
	if (received === "last-week") return mail.bucket === "last-week";
	if (received === "this-week") return mail.bucket === "today" || mail.bucket === "this-week";
	return true;
}
function matches(mail, parsed, filters, folder, scope, searching) {
	if ((!searching || scope === "current") && mail.folder !== folder) return false;
	if (filters.unread && !mail.unread) return false;
	if (filters.files && !mail.hasAttachment) return false;
	if (filters.toMe && !mail.toMe) return false;
	if (filters.invite && !mail.invite) return false;
	if (!searching) return true;
	if (parsed.from && !mail.fromKey.includes(parsed.from) && !mail.from.toLowerCase().includes(parsed.from)) return false;
	if (parsed.subject && !mail.subject.toLowerCase().includes(parsed.subject)) return false;
	if (parsed.hasAttachment === true && !mail.hasAttachment) return false;
	if (parsed.hasAttachment === false && mail.hasAttachment) return false;
	if (parsed.unread && !mail.unread) return false;
	if (!bucketOk(mail, parsed.received)) return false;
	const hay = `${mail.from} ${mail.subject} ${mail.preview} ${mail.attachmentName ?? ""}`.toLowerCase();
	for (const p of parsed.phrases) if (!hay.includes(p)) return false;
	for (const w of parsed.words) if (!hay.includes(w)) return false;
	return true;
}
function InboxSimulator() {
	const mission1Done = useSearchProgress((s) => s.mission1);
	const mission2Done = useSearchProgress((s) => s.mission2);
	const setMission1 = useSearchProgress((s) => s.setMission1);
	const setMission2 = useSearchProgress((s) => s.setMission2);
	const [mission, setMission] = (0, import_react.useState)(mission1Done ? 2 : 1);
	const [folder, setFolder] = (0, import_react.useState)("inbox");
	const [scope, setScope] = (0, import_react.useState)("current");
	const [query, setQuery] = (0, import_react.useState)("");
	const [committed, setCommitted] = (0, import_react.useState)("");
	const [filters, setFilters] = (0, import_react.useState)({
		unread: false,
		files: false,
		toMe: false,
		invite: false
	});
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [scopeOpen, setScopeOpen] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [hint, setHint] = (0, import_react.useState)("");
	const [shake, setShake] = (0, import_react.useState)(false);
	const searching = committed.trim().length > 0;
	const parsed = (0, import_react.useMemo)(() => parseQuery(committed), [committed]);
	const results = (0, import_react.useMemo)(() => MAILS.filter((m) => matches(m, parsed, filters, folder, scope, searching)), [
		parsed,
		filters,
		folder,
		scope,
		searching
	]);
	(0, import_react.useEffect)(() => {
		if (mission1Done && mission === 1) setMission(2);
	}, [mission1Done, mission]);
	function flash(msg) {
		setHint(msg);
		setShake(true);
		window.setTimeout(() => setShake(false), 220);
	}
	function runSearch(value = query) {
		setCommitted(value.trim());
		setSelected(null);
		setHint("");
	}
	function clearSearch() {
		setQuery("");
		setCommitted("");
		setSelected(null);
		setHint("");
	}
	function insertToken(token) {
		const next = query.trim() ? `${query.trim()} ${token}` : token;
		setQuery(next);
	}
	function onSelect(mail) {
		setSelected(mail.id);
		if (mission === 1) {
			if (mail.id === TARGET_ID) {
				setMission1();
				setMission(2);
				setHint("");
				return;
			}
			flash("Dat is niet de briefing. Zoek de pdf van Claes — opdracht 1, vorige week.");
		}
	}
	(0, import_react.useEffect)(() => {
		if (mission !== 2 || mission2Done) return;
		if (searching || folder !== "inbox" || !filters.unread) return;
		const unreadInbox = MAILS.filter((m) => m.folder === "inbox" && m.unread);
		if (results.length === unreadInbox.length) setMission2();
	}, [
		mission,
		mission2Done,
		searching,
		folder,
		filters.unread,
		results.length,
		setMission2
	]);
	const filterCount = Object.values(filters).filter(Boolean).length;
	const done = mission1Done && mission2Done;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-elevated)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 border-b border-border bg-surface-2 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-primary uppercase",
					children: "Oefeninbox · hogeschoolaccount"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-display text-xl font-medium text-fg",
					children: done ? "Beide opdrachten klaar" : mission === 1 ? "Opdracht 1 — vind de pdf" : "Opdracht 2 — alleen ongelezen"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-xl text-sm leading-relaxed text-muted",
					children: done ? "Je hebt het bereik verruimd, een operator gebruikt, en een lijstfilter gezet." : mission === 1 ? "Zoek de briefing van Annemie Claes: opdracht 1 Marketing, met pdf, vorige week. Ze ligt niet in Postvak IN." : "Wis de zoekopdracht. Open Postvak IN. Zet Filter op Ongelezen."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 self-start rounded-md bg-event-soft px-3 py-2 text-sm text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
					className: "size-4",
					"aria-hidden": true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: done ? "Klaar" : mission === 1 ? "Zoeken + bereik" : "Lijstfilter" })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid lg:grid-cols-[13.5rem_minmax(0,1fr)_18rem]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "border-b border-border bg-surface-2 p-3 lg:border-r lg:border-b-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 pb-2 text-xs font-medium tracking-wide text-muted uppercase",
						children: "Mappen"
					}), FOLDERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setFolder(f.id);
							setSelected(null);
						},
						className: cn("flex h-11 w-full items-center rounded-sm px-3 text-left text-sm", folder === f.id ? "bg-event-soft text-primary" : "text-muted hover:bg-bg-warm hover:text-fg"),
						children: f.label
					}, f.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 border-b border-border p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-subtle" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: query,
											onChange: (e) => setQuery(e.target.value),
											onKeyDown: (e) => {
												if (e.key === "Enter") runSearch();
											},
											placeholder: "Zoeken",
											"aria-label": "Zoeken",
											className: "h-11 w-full rounded-sm bg-bg px-10 text-sm shadow-[var(--shadow-border)] outline-none focus:ring-2 focus:ring-ring"
										}),
										query && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "absolute top-1/2 right-2 flex size-8 -translate-y-1/2 items-center justify-center rounded-sm text-muted hover:bg-bg-warm",
											"aria-label": "Zoekopdracht wissen",
											onClick: clearSearch,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setScopeOpen((o) => !o),
										className: "flex h-11 items-center gap-1 rounded-sm bg-bg px-3 text-sm shadow-[var(--shadow-border)]",
										children: [scope === "all" ? "Alle mappen" : "Huidige map", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4 text-muted" })]
									}), scopeOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute top-12 right-0 z-10 w-44 rounded-md bg-surface p-1 shadow-[var(--shadow-elevated)]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "flex h-10 w-full items-center rounded-sm px-3 text-left text-sm hover:bg-bg-warm",
											onClick: () => {
												setScope("current");
												setScopeOpen(false);
											},
											children: "Huidige map"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "flex h-10 w-full items-center rounded-sm px-3 text-left text-sm hover:bg-bg-warm",
											onClick: () => {
												setScope("all");
												setScopeOpen(false);
											},
											children: "Alle mappen"
										})]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-1.5",
								children: [[
									"from:Claes",
									"hasattachment:yes",
									"received:\"last week\"",
									"read:no",
									"subject:opdracht"
								].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => insertToken(t),
									className: "h-9 rounded-sm bg-bg-warm px-2.5 font-mono text-xs text-fg",
									children: t
								}, t)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									onClick: () => runSearch(),
									children: "Zoeken"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 border-b border-border px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: searching ? `${results.length} resultaten` : `${results.length} in ${FOLDERS.find((f) => f.id === folder)?.label}`
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setFilterOpen((o) => !o),
									className: cn("inline-flex h-10 items-center gap-2 rounded-sm px-3 text-sm", filterCount ? "bg-event-soft text-primary" : "text-muted hover:bg-bg-warm"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "size-4" }),
										"Filter",
										filterCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums",
											children: filterCount
										})
									]
								}), filterOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute top-11 right-0 z-10 w-52 rounded-md bg-surface p-1 shadow-[var(--shadow-elevated)]",
									children: [
										["unread", "Ongelezen"],
										["files", "Heeft bestanden"],
										["toMe", "Aan mij"],
										["invite", "Agenda-uitnodiging"]
									].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setFilters((f) => ({
											...f,
											[key]: !f[key]
										})),
										className: cn("flex h-10 w-full items-center rounded-sm px-3 text-left text-sm", filters[key] ? "bg-event-soft text-primary" : "hover:bg-bg-warm"),
										children: label
									}, key))
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "max-h-[28rem] divide-y divide-border overflow-y-auto",
							children: results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "px-4 py-10 text-center text-sm text-muted",
								children: "Geen berichten. Controleer het zoekbereik of wis een filter."
							}) : results.map((mail) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onSelect(mail),
								className: cn("flex w-full gap-3 px-3 py-3 text-left hover:bg-bg-warm", selected === mail.id && "bg-event-soft", mail.unread && "font-medium"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("mt-1.5 size-2 shrink-0 rounded-full", mail.unread ? "bg-primary" : "bg-transparent") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate text-sm text-fg",
												children: mail.from
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "shrink-0 text-xs text-subtle",
												children: mail.when
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "mt-0.5 flex items-center gap-1.5 truncate text-sm",
											children: [
												mail.hasAttachment && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-3.5 shrink-0 text-muted" }),
												mail.flagged && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3.5 shrink-0 text-warn" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate",
													children: mail.subject
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-0.5 block truncate text-xs text-muted",
											children: mail.preview
										})
									]
								})]
							}) }, mail.id))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "border-t border-border bg-surface-2 p-4 lg:border-t-0 lg:border-l",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("space-y-3", shake && "shake"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-wide text-primary uppercase",
								children: "Coach"
							}),
							done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg text-fg",
									children: "Zoeken én filteren: beide zitten."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-relaxed text-muted",
									children: "De pdf stond in Lesmateriaal — daarom Alle mappen. Ongelezen is een bril op de lijst, geen zoekopdracht."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 rounded-md bg-success-soft px-3 py-2 text-sm text-success",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Opgeslagen in je voortgang"]
								})
							] }) : mission === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg text-fg",
									children: "Stapel operators, verruim het bereik."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
									className: "space-y-2 text-sm leading-relaxed text-muted",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1. Zet Alle mappen" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2. Klik from:Claes en hasattachment:yes" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "3. Zoeken, daarna de briefing aanklikken" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs leading-relaxed text-subtle",
									children: "received:\"last week\" is optioneel maar snijdt extra ruis weg."
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-lg text-fg",
								children: "Nu de bril, niet de zoekbalk."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
								className: "space-y-2 text-sm leading-relaxed text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1. Kruisje: zoekopdracht wissen" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2. Map: Postvak IN" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "3. Filter → Ongelezen" })
								]
							})] }),
							hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-md bg-warn-soft px-3 py-2 text-sm text-warn",
								children: hint
							}),
							selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectedPane, { mail: MAILS.find((m) => m.id === selected) ?? null })
						]
					})
				})
			]
		})]
	});
}
function SelectedPane({ mail }) {
	if (!mail) return null;
	const folder = FOLDERS.find((f) => f.id === mail.folder)?.label;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-surface p-3 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-fg",
				children: mail.subject
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted",
				children: [
					mail.from,
					" · ",
					folder
				]
			}),
			mail.hasAttachment && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 flex items-center gap-1.5 text-xs text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-3.5" }), mail.attachmentName]
			})
		]
	});
}
var SEARCH_CHECKLIST = [
	{
		id: "s1",
		text: "Ik klik in het zoekvak bovenaan (of druk Ctrl+E) — niet in een willekeurige map-zoekbalk."
	},
	{
		id: "s2",
		text: "Ik kies het zoekbereik: Huidige map, Huidige postvak of Alle mappen."
	},
	{
		id: "s3",
		text: "Ik gebruik een operator zonder spatie na de dubbele punt: from:Claes, niet from: Claes."
	},
	{
		id: "s4",
		text: "Meerwoorden tussen aanhalingstekens: received:\"last week\" of \"opdracht 1\"."
	},
	{
		id: "s5",
		text: "AND, OR en NOT schrijf ik in hoofdletters."
	},
	{
		id: "s6",
		text: "Filter (Ongelezen, Heeft bestanden) gebruik ik om de lijst te versmallen, zoeken om iets terug te vinden."
	},
	{
		id: "s7",
		text: "Gericht / Overige is geen filter. Dat is een inbox-indeling — uitzetten als mails ‘verdwijnen’."
	},
	{
		id: "s8",
		text: "Ik wis de zoekopdracht met het kruisje als ik klaar ben, anders blijft Outlook in zoekmodus."
	}
];
var SEARCH_PITFALLS = [
	{
		title: "Verkeerd zoekbereik",
		problem: "Je zoekt in Postvak IN. De opdracht van de docent ligt in de map Lesmateriaal. Resultaat: 0 berichten.",
		fix: "Open het menu naast het zoekvak en kies Alle mappen (of de map waarin je denkt dat het zit)."
	},
	{
		title: "Spatie na de dubbele punt",
		problem: "from: Claes is voor Outlook twee losse woorden, geen operator. Je krijgt ruis of niets.",
		fix: "Plak vast: from:Claes of from:annemie.claes. Zonder spatie."
	},
	{
		title: "Gericht-inbox verwarren met een filter",
		problem: "Nieuwsbrieven en sommige mails van de hogeschool belanden in Overige. Het lijkt alsof Outlook ze niet vindt.",
		fix: "Kijk naar Overige, of zoek in Alle mappen. Gericht is een indeling, geen zoekfilter."
	},
	{
		title: "Enkel een vaag woord",
		problem: "Je typt marketing en krijgt 80 hits: lessen, nieuwsbrieven, de projectgroep.",
		fix: "Stapel: from:Claes subject:opdracht hasattachment:yes. Elke operator snijdt ruis weg."
	},
	{
		title: "Zoekmodus niet afgesloten",
		problem: "Je inbox toont nog steeds de 3 zoekresultaten. Nieuwe mail lijkt niet binnen te komen.",
		fix: "Klik op het kruisje in het zoekvak. Dan ben je terug in de gewone map."
	}
];
var SEARCH_SCENARIOS = [
	{
		title: "Opdracht van de docent met bijlage",
		when: "Je weet de naam, niet de map",
		query: "from:Claes hasattachment:yes",
		tip: "Zet het bereik op Alle mappen. Heeft de docent meerdere mails, voeg subject:opdracht toe."
	},
	{
		title: "Ongelezen voor de les",
		when: "Tien minuten, Postvak IN puilt uit",
		query: "Filter → Ongelezen",
		tip: "Geen zoekopdracht nodig. Het Filter-menu boven de lijst toont alleen wat je nog niet opende."
	},
	{
		title: "Pdf’s van deze maand",
		when: "Verslagen en slides terugzoeken",
		query: "hasattachment:yes received:\"this month\"",
		tip: "attachment:pdf is strenger als je alleen pdf’s wilt, niet Excel. Werkt in web en nieuwe Outlook."
	},
	{
		title: "Agenda-uitnodiging kwijt",
		when: "Iemand stuurde een meeting, jij ziet ze niet in de agenda",
		query: "Filter → Heeft agenda-uitnodigingen  · of in Agenda: organizer:naam",
		tip: "Mail en agenda zijn aparte zoekvakken. In Agenda: is:recurring voor reeksen."
	}
];
var OPERATORS = [
	{
		token: "from:",
		example: "from:Claes",
		use: "Alles van die afzender, ook als de naam in de mail zelf voorkomt."
	},
	{
		token: "subject:",
		example: "subject:opdracht",
		use: "Alleen de onderwerpregel. Handig als het woord ook in handtekeningen zit."
	},
	{
		token: "hasattachment:yes",
		example: "hasattachment:yes",
		use: "Berichten mét een bestand. Gelijk aan hasattachment:true."
	},
	{
		token: "received:",
		example: "received:\"last week\"",
		use: "today, yesterday, last week, this month. Meerwoorden tussen aanhalingstekens."
	},
	{
		token: "read:no",
		example: "read:no",
		use: "Ongelezen. Zelfde idee als het Filter-menu, maar combineerbaar met from:."
	},
	{
		token: "\"…\"",
		example: "\"opdracht 1\"",
		use: "Exacte woordvolgorde. Zonder aanhalingstekens zoekt Outlook de woorden los."
	}
];
var SEARCH_QUIZ = [
	{
		id: "sq1",
		question: "Je zoekt de pdf van prof. Claes. Je typt from: Claes (met spatie). Wat gebeurt er?",
		choices: [
			"Outlook gebruikt de operator Van en toont alleen haar mails",
			"De spatie breekt de operator: Outlook zoekt losse woorden",
			"Outlook weigert de zoekopdracht"
		],
		answer: 1,
		why: "Geen spatie na de dubbele punt. Correct is from:Claes."
	},
	{
		id: "sq2",
		question: "De opdracht zit in de map Lesmateriaal. Jij zoekt in Postvak IN en krijgt niets. Eerste check?",
		choices: [
			"Het zoekbereik: kies Alle mappen of open Lesmateriaal",
			"Je account is stuk, meld je af en aan",
			"Gebruik hoofdletters in de naam van de docent"
		],
		answer: 0,
		why: "Zoeken is standaard beperkt tot de map die openstaat. Vergroot het bereik."
	},
	{
		id: "sq3",
		question: "Wat is het verschil tussen Filter en Zoeken?",
		choices: [
			"Er is geen verschil",
			"Filter versmalt de open map (ongelezen, bijlagen). Zoeken vindt iets, ook met operators",
			"Filter werkt alleen in de klassieke Windows-app"
		],
		answer: 1,
		why: "Filter is een bril op de lijst. Zoeken is een vraag aan het postvak."
	},
	{
		id: "sq4",
		question: "Welke zoekopdracht vindt mails van vorige week mét bijlage?",
		choices: [
			"bijlage vorige week",
			"hasattachment:yes received:\"last week\"",
			"filter:pdf AND week-1"
		],
		answer: 1,
		why: "Operators in het Engels, datums met meerdere woorden tussen aanhalingstekens. AND mag, maar is hier overbodig: spaties betekenen én."
	},
	{
		id: "sq5",
		question: "Je ziet mails van de studentenkring niet in Postvak IN, wel soms in Overige. Oorzaak?",
		choices: [
			"De mails zijn verwijderd",
			"De indeling Gericht / Overige splitst je inbox — dat is geen zoekfilter",
			"hasattachment:yes staat per ongeluk aan"
		],
		answer: 1,
		why: "Gericht is een inbox-weergave. Open Overige of zoek in alle mappen."
	},
	{
		id: "sq6",
		question: "AND, OR en NOT in een zoekopdracht. Hoe moet je ze schrijven?",
		choices: [
			"In hoofdletters: opdracht AND bijlage NOT nieuwsbrief",
			"In kleine letters, anders negeert Outlook ze",
			"Alleen in de klassieke app, nooit op het web"
		],
		answer: 0,
		why: "Logische operatoren moeten in hoofdletters. Kleine letters telt Outlook als gewone woorden."
	}
];
var SEARCH_PLATFORM_STEPS = {
	web: {
		title: "Outlook op het web",
		steps: [
			{
				title: "Zoekvak bovenaan",
				body: "Ga naar outlook.office.com. Het vak Zoeken staat in de middenbalk. Typ of druk niet per ongeluk in de mappenlijst."
			},
			{
				title: "Bereik kiezen",
				body: "Klik in het vak. Kies Huidige map of een breder bereik. Docentenmail staat vaak niet in Postvak IN."
			},
			{
				title: "Filters of operators",
				body: "Rechts in het zoekvak: Filters (trechter). Of typ from:naam hasattachment:yes en druk Enter."
			},
			{
				title: "Lijstfilter",
				body: "Boven de berichtenlijst: Filter. Ongelezen, Gemarkeerd, Aan mij, Heeft bestanden, Vermeldt mij, agenda-uitnodigingen."
			},
			{
				title: "Wissen",
				body: "Kruisje in het zoekvak. Anders blijf je in de resultaten en lijkt nieuwe mail weg."
			}
		]
	},
	new: {
		title: "Nieuwe Outlook (app)",
		steps: [
			{
				title: "Ctrl+E of klikken",
				body: "Het zoekvak zit bovenaan het venster. Recente zoekopdrachten en contacten verschijnen als suggesties."
			},
			{
				title: "Server-side zoeken",
				body: "De nieuwe app zoekt op de server van Microsoft 365. Oude mail kan ontbreken als die niet meer in de cloud-index zit."
			},
			{
				title: "Filters na de zoekactie",
				body: "Na Enter: knop Filters boven de resultaten. Afzender, datum, bijlagen, map. Chips kun je één voor één wegklikken."
			},
			{
				title: "Geavanceerd",
				body: "Trechter of chevron rechts in het zoekvak opent velden: Van, Onderwerp, datum, heeft bijlagen — zonder syntax."
			},
			{
				title: "Agenda apart",
				body: "Open Agenda en zoek daar. organizer:naam of is:recurring werkt alleen in een agendamap."
			}
		]
	},
	classic: {
		title: "Klassieke Outlook (Windows)",
		steps: [
			{
				title: "Zoekvak of Ctrl+E",
				body: "Bovenaan de map. Zodra je klikt, verschijnt het lint Zoeken met de groep Verfijnen."
			},
			{
				title: "Verfijnen op het lint",
				body: "Van, Onderwerp, Heeft bijlagen, Ongelezen, Deze week — knoppen i.p.v. operators. Combineer ze."
			},
			{
				title: "Geavanceerd zoeken",
				body: "Pijltje rechts in het zoekvak. Extra velden en locatie (huidige map / submappen / alle Outlook-items)."
			},
			{
				title: "Operators blijven werken",
				body: "Je mag nog altijd from: en hasattachment:yes typen. AND / OR / NOT in hoofdletters."
			},
			{
				title: "Index",
				body: "Klassiek gebruikt een lokale zoekindex. Als resultaten ontbreken: Windows-zoekindex controleren, of wachten tot Outlook klaar is met indexeren."
			}
		]
	}
};
function SearchGuide() {
	const [active, setActive] = (0, import_react.useState)("start");
	const markVisited = useSearchProgress((s) => s.markVisited);
	const visited = useSearchProgress((s) => s.visited);
	const mission1 = useSearchProgress((s) => s.mission1);
	const mission2 = useSearchProgress((s) => s.mission2);
	const checks = useSearchProgress((s) => s.checks);
	const quiz = useSearchProgress((s) => s.quiz);
	(0, import_react.useEffect)(() => {
		useSearchProgress.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		markVisited(active);
	}, [active, markVisited]);
	const checkedCount = SEARCH_CHECKLIST.filter((c) => checks[c.id]).length;
	const quizDone = Object.keys(quiz).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh overflow-x-hidden bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#inhoud",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-fg",
				children: "Naar inhoud"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border bg-surface/80 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-3 text-fg no-underline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-9 items-center justify-center rounded-sm bg-primary text-primary-fg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								className: "size-4",
								"aria-hidden": true
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg font-medium leading-none text-fg",
							children: "Zoek"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "Outlook-gids · BM1"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-sm text-muted sm:block",
						children: "10 minuten"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid min-w-0 max-w-6xl lg:grid-cols-[16.5rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Hoofdstukken",
					className: "sticky top-0 z-20 min-w-0 overflow-x-hidden border-b border-border bg-bg/95 lg:h-dvh lg:overflow-y-auto lg:border-r lg:border-b-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-1 overflow-x-auto px-3 py-2 lg:flex-col lg:gap-0.5 lg:px-4 lg:py-6",
						children: SEARCH_SECTIONS.map((s) => {
							const isActive = active === s.id;
							const done = Boolean(visited[s.id]) && (s.id !== "oefenen" || mission1 && mission2) && (s.id !== "checklist" || checkedCount === SEARCH_CHECKLIST.length) && (s.id !== "quiz" || quizDone === SEARCH_QUIZ.length);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setActive(s.id),
								className: cn("flex h-11 shrink-0 items-center gap-2 rounded-md px-3 text-left text-sm whitespace-nowrap transition-colors duration-150 lg:h-10 lg:w-full", isActive ? "bg-primary text-primary-fg" : "text-muted hover:bg-bg-warm hover:text-fg"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden lg:flex",
										children: done && !isActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "size-3.5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "lg:hidden",
										children: s.short
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden lg:inline",
										children: s.label
									})
								]
							}, s.id);
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					id: "inhoud",
					className: "min-w-0 overflow-x-hidden px-4 py-8 sm:px-8 sm:py-10",
					children: [
						active === "start" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Start, { onNext: () => setActive("begrippen") }),
						active === "begrippen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Begrippen, { onNext: () => setActive("oefenen") }),
						active === "oefenen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Oefenen, { onNext: () => setActive("stappen") }),
						active === "stappen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stappen, { onNext: () => setActive("operators") }),
						active === "operators" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Operators, { onNext: () => setActive("situaties") }),
						active === "situaties" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Situaties, { onNext: () => setActive("valkuilen") }),
						active === "valkuilen" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Valkuilen, { onNext: () => setActive("checklist") }),
						active === "checklist" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checklist, { onNext: () => setActive("quiz") }),
						active === "quiz" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toets, {})
					]
				})]
			})
		]
	});
}
function SectionHead({ kicker, title, lead }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "stagger-in mb-8 max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-primary uppercase",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-3xl font-medium tracking-tight text-fg sm:text-4xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base leading-relaxed text-muted",
				children: lead
			})
		]
	});
}
function NextButton({ onNext, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			size: "lg",
			onClick: onNext,
			children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
		})
	});
}
function Start({ onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Handleiding",
			title: "Zoeken en filteren in Outlook, zonder 80 hits op ‘marketing’.",
			lead: "Voor 1ste bachelor Bedrijfsmanagement. In tien minuten leer je het zoekvak, het bereik, operators en het Filter-menu — en het verschil daartussen."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				{
					icon: Search,
					title: "Zoeken vindt iets",
					body: "from:Claes, een onderwerp, een pdf. Werkt over mappen heen als je het bereik verruimt."
				},
				{
					icon: Funnel,
					title: "Filter is een bril",
					body: "Ongelezen, Heeft bestanden, Aan mij. De map blijft dezelfde, de lijst wordt smaller."
				},
				{
					icon: TriangleAlert,
					title: "Huidige map",
					body: "Standaard zoekt Outlook alleen waar je bent. Lesmateriaal bestaat dan niet."
				}
			].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(card.icon, {
						className: "size-5 text-primary",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-lg font-medium",
						children: card.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: card.body
					})
				]
			}, card.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Eerst het verschil"
		})
	] });
}
function Begrippen({ onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Begrippen",
			title: "Vier dingen die op elkaar lijken, en het niet zijn.",
			lead: "Studenten verwarren ze. Outlook ook, visueel: alles zit bovenaan in hetzelfde scherm."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-lg shadow-[var(--shadow-border)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[32rem] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "bg-surface-2 text-xs tracking-wide text-muted uppercase",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Wat"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Doet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Wanneer"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
					className: "bg-surface",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: "Zoeken"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Vraagt het postvak af. Operators, woorden, datums."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Iets terugvinden"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: "Filter"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Bril op de open lijst: ongelezen, bijlagen, aan mij."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "De berg smaller maken"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: "Bereik"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Huidige map, postvak of alle mappen."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "0 resultaten? Eerst hier."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: "Gericht / Overige"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Inbox-indeling, geen zoekfilter. Nieuwsbrieven glippen weg."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted",
									children: "Mail ‘verdwenen’?"
								})
							]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 max-w-2xl text-sm leading-relaxed text-muted",
			children: [
				"Operators blijven Engels, ook in een Nederlandse Outlook:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-medium text-fg",
					children: "from:"
				}),
				",",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-medium text-fg",
					children: "subject:"
				}),
				",",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-medium text-fg",
					children: "hasattachment:yes"
				}),
				". De knoppen heten Zoeken, Filters en Filter."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Oefen het in de nep-inbox"
		})
	] });
}
function Oefenen({ onNext }) {
	const m1 = useSearchProgress((s) => s.mission1);
	const m2 = useSearchProgress((s) => s.mission2);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Oefeninbox",
			title: "Eerst hier. Dan in je schoolaccount.",
			lead: "Twee opdrachten: een pdf terugvinden die niet in Postvak IN zit, en daarna de lijst op ongelezen zetten."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InboxSimulator, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex flex-wrap gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("inline-flex items-center gap-1.5 rounded-md px-3 py-2", m1 ? "bg-success-soft text-success" : "bg-bg-warm text-muted"),
				children: [m1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "size-3.5" }), "Pdf gevonden"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("inline-flex items-center gap-1.5 rounded-md px-3 py-2", m2 ? "bg-success-soft text-success" : "bg-bg-warm text-muted"),
				children: [m2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "size-3.5" }), "Ongelezen-filter"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Stappen in de echte Outlook"
		})
	] });
}
function Stappen({ onNext }) {
	const [platform, setPlatform] = (0, import_react.useState)("web");
	const data = SEARCH_PLATFORM_STEPS[platform];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "In het echt",
			title: "Zelfde zoekvak, drie Outlooks.",
			lead: "Web en de nieuwe app delen bijna dezelfde knoppen. Klassiek heeft een lint Zoeken. Operators werken overal."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6 flex flex-wrap gap-2",
			children: [
				[
					"web",
					"Web",
					Laptop
				],
				[
					"new",
					"Nieuwe app",
					Monitor
				],
				[
					"classic",
					"Klassiek",
					AppWindow
				]
			].map(([id, label, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setPlatform(id),
				className: cn("inline-flex h-11 items-center gap-2 rounded-md px-4 text-sm transition-colors duration-150", platform === id ? "bg-primary text-primary-fg" : "bg-surface text-muted shadow-[var(--shadow-border)] hover:text-fg"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
			}, id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 text-sm font-medium text-fg",
			children: data.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "space-y-3",
			children: data.steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-4 rounded-lg bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-8 shrink-0 items-center justify-center rounded-sm bg-event-soft font-display text-sm text-primary tabular-nums",
					children: i + 1
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-medium text-fg",
					children: step.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: step.body
				})] })]
			}, step.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-sm leading-relaxed text-muted",
			children: [
				"Sneltoets:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
					className: "rounded-xs bg-bg-warm px-1.5 py-0.5 text-fg",
					children: "Ctrl+E"
				}),
				" ",
				"zet de cursor in het zoekvak (Windows). Op Mac:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
					className: "rounded-xs bg-bg-warm px-1.5 py-0.5 text-fg",
					children: "Cmd+E"
				}),
				"."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "De operators die je nodig hebt"
		})
	] });
}
function Operators({ onNext }) {
	const [active, setActive] = (0, import_react.useState)(OPERATORS[0].token);
	const current = OPERATORS.find((o) => o.token === active) ?? OPERATORS[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Operators",
			title: "Geen spatie na de dubbele punt.",
			lead: "Zes patronen dekken bijna alles in het eerste jaar. Combineer ze met een spatie — dat betekent én."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[14rem_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto lg:flex-col",
				children: OPERATORS.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setActive(o.token),
					className: cn("h-11 shrink-0 rounded-md px-4 text-left text-sm lg:w-full", active === o.token ? "bg-primary text-primary-fg" : "bg-surface text-muted shadow-[var(--shadow-border)] hover:text-fg"),
					children: o.token
				}, o.token))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm text-primary",
						children: current.example
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-2xl font-medium",
						children: current.token
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: current.use
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-lg bg-surface-2 p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "Combineren"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Spatie = én.",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "rounded-xs bg-bg-warm px-1.5 py-0.5 text-fg",
							children: "from:Claes hasattachment:yes"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "rounded-xs bg-bg-warm px-1.5 py-0.5 text-fg",
							children: "AND OR NOT"
						}),
						" ",
						"in hoofdletters.",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "rounded-xs bg-bg-warm px-1.5 py-0.5 text-fg",
							children: "opdracht NOT nieuwsbrief"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Agenda (in de agendamap):",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "rounded-xs bg-bg-warm px-1.5 py-0.5 text-fg",
							children: "organizer:Claes"
						}),
						" ",
						"·",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "rounded-xs bg-bg-warm px-1.5 py-0.5 text-fg",
							children: "is:recurring"
						})
					] })
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Vier BM-situaties"
		})
	] });
}
function Situaties({ onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Situaties",
			title: "Kopieer de zoekopdracht, niet het verhaal.",
			lead: "Pas de naam van de docent aan. Houd de operator."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: SEARCH_SCENARIOS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: s.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: s.when
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-mono text-sm text-primary",
						children: s.query
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 rounded-md bg-surface-2 px-3 py-2 text-sm leading-relaxed text-muted",
						children: s.tip
					})
				]
			}, s.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Vijf valkuilen"
		})
	] });
}
function Valkuilen({ onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Valkuilen",
			title: "Nul resultaten is meestal het bereik.",
			lead: "Niet de zoekmachine. Jij stond in de verkeerde map, of je zette een spatie te veel."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: SEARCH_PITFALLS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "flex items-center gap-2 font-display text-lg font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-warn" }), p.title]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: p.problem
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 rounded-md bg-success-soft px-3 py-2 text-sm leading-relaxed text-success",
						children: p.fix
					})
				]
			}, p.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Checklist voor je Enter drukt"
		})
	] });
}
function Checklist({ onNext }) {
	const checks = useSearchProgress((s) => s.checks);
	const toggle = useSearchProgress((s) => s.toggleCheck);
	const n = SEARCH_CHECKLIST.filter((c) => checks[c.id]).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Checklist",
			title: "Acht punten, daarna Enter.",
			lead: "Vink af terwijl je in het echte postvak zoekt. Voortgang blijft op dit toestel."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-4 text-sm tabular-nums text-muted",
			children: [
				n,
				" / ",
				SEARCH_CHECKLIST.length,
				" afgevinkt"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: SEARCH_CHECKLIST.map((c) => {
				const on = Boolean(checks[c.id]);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => toggle(c.id),
					className: cn("flex min-h-14 w-full items-start gap-3 rounded-lg px-4 py-3 text-left text-sm leading-snug shadow-[var(--shadow-border)]", on ? "bg-success-soft text-success" : "bg-surface text-fg"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-xs ring-1", on ? "bg-success text-primary-fg ring-success" : "ring-border"),
						children: on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" })
					}), c.text]
				}) }, c.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextButton, {
			onNext,
			children: "Toets van zes vragen"
		})
	] });
}
function Toets() {
	const answers = useSearchProgress((s) => s.quiz);
	const setQuiz = useSearchProgress((s) => s.setQuiz);
	const reset = useSearchProgress((s) => s.reset);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			kicker: "Toets",
			title: "Zes vragen. Directe uitleg.",
			lead: "Geen cijfer — wel of je het bereik, de spatie en Gericht/Overige uit elkaar houdt."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quiz, {
			items: SEARCH_QUIZ,
			answers,
			setAnswer: setQuiz,
			onReset: reset
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-10 flex items-center gap-2 text-sm text-subtle",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" }), "Labels verschillen licht per taal en versie. Twijfel je: zoek de trechter Filters, niet alleen het woord Filter boven de lijst."]
		})
	] });
}
function ZoekenPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchGuide, {});
}
//#endregion
export { ZoekenPage as component };
