import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-CxklWp97.js
var SECTIONS = [
	{
		id: "start",
		label: "Start",
		short: "Start"
	},
	{
		id: "begrippen",
		label: "Begrippen",
		short: "Begrip"
	},
	{
		id: "oefenen",
		label: "Oefenagenda",
		short: "Oefen"
	},
	{
		id: "stappen",
		label: "Stappen in Outlook",
		short: "Stappen"
	},
	{
		id: "patronen",
		label: "Herhaalpatronen",
		short: "Patronen"
	},
	{
		id: "wijzigen",
		label: "Wijzigen & schrappen",
		short: "Wijzig"
	},
	{
		id: "situaties",
		label: "Studentensituaties",
		short: "Situaties"
	},
	{
		id: "valkuilen",
		label: "Valkuilen",
		short: "Valkuilen"
	},
	{
		id: "checklist",
		label: "Checklist",
		short: "Check"
	},
	{
		id: "quiz",
		label: "Toets jezelf",
		short: "Toets"
	}
];
var useProgress = create()(persist((set, get) => ({
	visited: { start: true },
	checks: {},
	quiz: {},
	simulatorComplete: false,
	exceptionComplete: false,
	markVisited: (id) => set({ visited: {
		...get().visited,
		[id]: true
	} }),
	toggleCheck: (id) => set({ checks: {
		...get().checks,
		[id]: !get().checks[id]
	} }),
	setQuiz: (id, choice) => set({ quiz: {
		...get().quiz,
		[id]: choice
	} }),
	setSimulatorComplete: () => set({ simulatorComplete: true }),
	setExceptionComplete: () => set({ exceptionComplete: true }),
	reset: () => set({
		visited: { start: true },
		checks: {},
		quiz: {},
		simulatorComplete: false,
		exceptionComplete: false
	})
}), {
	name: "reeks-progress-v1",
	skipHydration: true
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
//#endregion
export { cn as n, useProgress as r, SECTIONS as t };
