import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-progress-CgbG9vcV.js
var SEARCH_SECTIONS = [
	{
		id: "start",
		label: "Start",
		short: "Start"
	},
	{
		id: "begrippen",
		label: "Zoeken vs filter",
		short: "Begrip"
	},
	{
		id: "oefenen",
		label: "Oefeninbox",
		short: "Oefen"
	},
	{
		id: "stappen",
		label: "Stappen in Outlook",
		short: "Stappen"
	},
	{
		id: "operators",
		label: "Operators",
		short: "Operators"
	},
	{
		id: "situaties",
		label: "Studentensituaties",
		short: "Situaties"
	},
	{
		id: "valkuilen",
		label: "Valkuilen",
		short: "Valkuilen"
	},
	{
		id: "checklist",
		label: "Checklist",
		short: "Check"
	},
	{
		id: "quiz",
		label: "Toets jezelf",
		short: "Toets"
	}
];
var useSearchProgress = create()(persist((set, get) => ({
	visited: { start: true },
	checks: {},
	quiz: {},
	mission1: false,
	mission2: false,
	markVisited: (id) => set({ visited: {
		...get().visited,
		[id]: true
	} }),
	toggleCheck: (id) => set({ checks: {
		...get().checks,
		[id]: !get().checks[id]
	} }),
	setQuiz: (id, choice) => set({ quiz: {
		...get().quiz,
		[id]: choice
	} }),
	setMission1: () => set({ mission1: true }),
	setMission2: () => set({ mission2: true }),
	reset: () => set({
		visited: { start: true },
		checks: {},
		quiz: {},
		mission1: false,
		mission2: false
	})
}), {
	name: "outlook-gids-search-v1",
	skipHydration: true
}));
//#endregion
export { useSearchProgress as n, SEARCH_SECTIONS as t };
