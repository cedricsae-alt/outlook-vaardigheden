import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as cn, r as useProgress } from "./utils-CxklWp97.mjs";
import { L as require_jsx_runtime, _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronRight, c as Repeat, m as Funnel, o as Search } from "../_libs/lucide-react.mjs";
import { n as useSearchProgress } from "./search-progress-CgbG9vcV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DRt5qbIz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Hub() {
	const reeksSim = useProgress((s) => s.simulatorComplete);
	const reeksExc = useProgress((s) => s.exceptionComplete);
	const search1 = useSearchProgress((s) => s.mission1);
	const search2 = useSearchProgress((s) => s.mission2);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh overflow-x-hidden bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-border bg-surface/80 backdrop-blur-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-9 items-center justify-center rounded-sm bg-primary text-primary-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							className: "size-4",
							"aria-hidden": true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-medium leading-none text-fg",
						children: "Outlook-gids"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "1ste bachelor Bedrijfsmanagement"
					})] })]
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-4 py-10 sm:px-8 sm:py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "stagger-in mb-10 max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-primary uppercase",
						children: "Twee handleidingen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl font-medium tracking-tight text-fg sm:text-4xl",
						children: "Outlook zoals je het in het eerste jaar nodig hebt."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base leading-relaxed text-muted",
						children: "Geen volledige Microsoft-help. Wel de twee vaardigheden waar BM-studenten op vastlopen: reeksen in de agenda, en mail terugvinden zonder 80 hits."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuideCard, {
					to: "/reeks",
					icon: Repeat,
					kicker: "Agenda",
					title: "Terugkerende afspraken",
					body: "Wekelijkse projectgroep, studieblok, stagecheck. Eén les schrappen zonder het semester mee te nemen.",
					time: "10 min",
					done: reeksSim && reeksExc,
					doneLabel: "Oefenagenda klaar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuideCard, {
					to: "/zoeken",
					icon: Funnel,
					kicker: "Mail",
					title: "Zoeken en filters",
					body: "Het zoekvak, het bereik, operators zoals from: en hasattachment:yes, en het Filter-menu.",
					time: "10 min",
					done: search1 && search2,
					doneLabel: "Oefeninbox klaar"
				})]
			})]
		})]
	});
}
function GuideCard({ to, icon: Icon, kicker, title, body, time, done, doneLabel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "group flex flex-col rounded-xl bg-surface p-6 text-fg no-underline shadow-[var(--shadow-border)] transition-shadow duration-150 hover:shadow-[var(--shadow-elevated)] sm:p-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-11 items-center justify-center rounded-md bg-event-soft text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: time
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-xs font-medium tracking-wide text-primary uppercase",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-2xl font-medium text-fg",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 flex-1 text-sm leading-relaxed text-muted",
				children: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("text-sm", done ? "text-success" : "text-muted"),
					children: done ? doneLabel : "Nog niet geoefend"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex h-11 items-center gap-1 text-sm font-medium text-primary",
					children: ["Openen", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 transition-transform duration-150 group-hover:translate-x-0.5" })]
				})]
			})
		]
	});
}
function Home() {
	(0, import_react.useEffect)(() => {
		useProgress.persist.rehydrate();
		useSearchProgress.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hub, {});
}
//#endregion
export { Home as component };
